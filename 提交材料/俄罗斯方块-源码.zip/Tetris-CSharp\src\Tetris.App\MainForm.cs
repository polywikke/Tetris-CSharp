using System.Diagnostics;
using System.Drawing;
using Tetris.AI;
using Tetris.App.Input;
using Tetris.Core;

namespace Tetris.App;

/// <summary>
/// 主窗口（B 负责）：负责"定时器驱动逻辑帧 + 把状态画出来 + 把按键翻译成命令"。
/// 它不认识 A 的规则实现，只认识 <see cref="IGameEngine"/> / <see cref="IGameRules"/> 两个接口；
/// AI 也是通过 <see cref="IPlayerAgent"/> 接入的，界面不知道 C 的启发式是怎么算的。
/// <para>
/// 输入分两路：
/// <list type="bullet">
/// <item><b>一次性</b>命令（旋转、硬降、暂停）在 <see cref="ProcessCmdKey"/> 里按下当帧直接下发，
/// 按住不放不会连发；</item>
/// <item><b>可重复</b>命令（左右移动、软降）只登记到 <see cref="KeyRepeater"/>，由它在每个逻辑帧
/// 之前按 DAS 180ms / ARR 40ms 决定发不发、发几条。</item>
/// </list>
/// </para>
/// <para>
/// F3 是"人机轮流"开关：同一个棋盘、同一个引擎实例，打开时 AI 每帧贡献一条命令，
/// 关闭时玩家立刻接手当前方块（AI 期间玩家的移动/旋转/硬降被忽略，但暂停仍然有效）。
/// </para>
/// </summary>
public sealed class MainForm : Form
{
    /// <summary>逻辑帧固定 1/60 秒，与渲染帧率解耦。</summary>
    private const double FrameMs = 1000.0 / 60.0;

    /// <summary>一次刷新最多补 4 帧（2× 速度时需要 2 帧，留一倍余量），防止卡顿后疯狂追帧。</summary>
    private const int MaxCatchUpFrames = 4;

    /// <summary>下落速度倍率（F4 循环）。1× 就是等级表原本的节奏。</summary>
    private static readonly double[] Speeds = { 0.5, 1.0, 2.0 };

    /// <summary>AI 分步档：相邻两条指令的间隔（毫秒）。</summary>
    private const double AiStepMs = 110;

    /// <summary>AI 分步档：硬降落块后的停顿，让人看清它落在哪、消没消行。</summary>
    private const double AiPiecePauseMs = 140;

    /// <summary>
    /// AI 分步档冻结重力后，如果同一块超过这个时间没有一条成功指令，就替它硬降——
    /// 否则 AI 一旦原地打转，画面会彻底停住。
    /// </summary>
    private const double AiStallLimitMs = 2500;

    private readonly IGameEngine _engine = AppBootstrap.CreateEngine(Environment.TickCount);
    private readonly IHighScoreStore _store = AppBootstrap.CreateStore();
    private readonly BoardView _board = new();
    private readonly KeyRepeater _keys = new();
    private readonly System.Windows.Forms.Timer _timer = new() { Interval = 15 };
    private readonly Stopwatch _clock = Stopwatch.StartNew();

    private Label _scoreLabel = null!;
    private Label _highLabel = null!;
    private Label _levelLabel = null!;
    private Label _linesLabel = null!;
    private Label _speedLabel = null!;
    private Label _aiPaceLabel = null!;
    private Label _nextLabel = null!;
    private Label _hintLabel = null!;
    private Label _aiLabel = null!;
    private Label _noticeLabel = null!;
    private NextPieceView[] _previews = Array.Empty<NextPieceView>();

    private HighScore? _highScore;
    private TimeSpan _lastTick;
    private double _pendingMs;
    private int _speedIndex = 1;
    private long _lastSignature = -1;
    private bool _aiFast;
    private double _aiElapsedMs;
    private double _aiPauseLeftMs;
    private double _aiStallMs;
    private bool _savedThisRound;
    private bool _newRecordThisRound;
    private IPlayerAgent? _agent;

    public MainForm()
    {
        Text = "俄罗斯方块 · C# 大作业";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(860, 660);
        MinimumSize = new Size(720, 560);
        BackColor = Palette.Background;
        KeyPreview = true;
        AutoScaleMode = AutoScaleMode.Dpi;

        _board.State = _engine.State;
        Controls.Add(BuildLayout());

        Load += OnFormLoad;
        FormClosing += (_, _) => _timer.Stop();
        _timer.Tick += OnFrame;
        KeyUp += (_, e) => _keys.Release(e.KeyCode);
    }

    /// <summary>
    /// 键盘入口。注意 <c>keyData</c> 可能带 Ctrl/Shift 之类的修饰位，
    /// 这里先裁成纯键码，保证按下与松开用的是同一个 key（否则"按住不连发"会失效）。
    /// </summary>
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
    {
        var key = keyData & Keys.KeyCode;

        if (key == Keys.F2)
        {
            StartNewGame();
            return true;
        }

        if (key == Keys.F3)
        {
            ToggleAgent();
            return true;
        }

        if (key == Keys.F4)
        {
            CycleSpeed();
            return true;
        }

        if (key == Keys.F5)
        {
            ToggleAiPace();
            return true;
        }

        var command = KeyMap.ToCommand(key);
        if (command is null)
        {
            return base.ProcessCmdKey(ref msg, keyData);
        }

        // 同一个键的第二条 KeyDown 就是 Windows 的自动重复：吞掉，别让它一按就刷出一串命令。
        if (!_keys.Press(key, NowMs()))
        {
            return true;
        }

        if (KeyMap.IsAutoRepeat(key))
        {
            // 方向键 / 软降不在这里执行，交给 OnFrame 的 KeyRepeater 按 DAS/ARR 节奏发。
            return true;
        }

        ApplyPlayerCommand(command.Value);
        return true;
    }

    private void OnFormLoad(object? sender, EventArgs e)
    {
        var loaded = _store.Load();
        _highScore = loaded.Record;

        // 每种情况的提示都控制在 16 字以内（侧栏不许被长句撑破）。
        _noticeLabel.Text = loaded.Status switch
        {
            HighScoreLoadStatus.Missing => "首次运行，暂无存档",
            HighScoreLoadStatus.Ok => "已读取最高分",
            HighScoreLoadStatus.Corrupted => "存档损坏，已忽略",
            _ => "存档读取失败，已忽略",
        };

        _board.HighScore = _highScore?.Score ?? 0;
        StartNewGame();
        _timer.Start();
    }

    private void StartNewGame()
    {
        _engine.Start(Environment.TickCount);
        _keys.Clear();
        _agent?.Reset();
        _board.State = _engine.State;
        _savedThisRound = false;
        _newRecordThisRound = false;
        _pendingMs = 0;
        _lastSignature = -1;
        _aiElapsedMs = 0;
        _aiPauseLeftMs = 0;
        _aiStallMs = 0;
        _lastTick = _clock.Elapsed;
        UpdateHud();
        _board.Invalidate();
    }

    private void OnFrame(object? sender, EventArgs e)
    {
        var now = _clock.Elapsed;
        var nowMs = now.TotalMilliseconds;
        var deltaMs = nowMs - _lastTick.TotalMilliseconds;
        _lastTick = now;

        // AI 分步档冻结重力：方块只随 AI 指令移动。
        // 否则高等级下重力（最快 50ms/格）会跑在 110ms 一步的 AI 前面，
        // 方块在指令没发完时就被锁定在错误列——这就是"切到分步就很快顶死"的原因。
        var aiSlow = _agent is not null && !_aiFast;
        if (aiSlow)
        {
            _pendingMs = 0;
        }
        else
        {
            // 速度倍率只缩放"逻辑时间"，不影响按键响应。
            _pendingMs += deltaMs * Speeds[_speedIndex];
        }

        // 顺序固定：先吃输入，再推进逻辑帧，最后结算/重绘。
        FeedInput(deltaMs);

        if (!aiSlow)
        {
            var steps = 0;
            while (_pendingMs >= FrameMs && steps < MaxCatchUpFrames)
            {
                _engine.Tick();
                _pendingMs -= FrameMs;
                steps++;
            }

            if (steps >= MaxCatchUpFrames)
            {
                _pendingMs = 0;
            }
        }

        SaveHighScoreIfNeeded();

        // 画面真的会变才重绘：暂停、等重力那几十帧都不再空转。
        var signature = StateSignature();
        if (signature == _lastSignature)
        {
            return;
        }

        _lastSignature = signature;
        _board.State = _engine.State;
        _board.HighScore = _highScore?.Score ?? 0;
        _board.IsNewRecord = _newRecordThisRound;
        UpdateHud();
        _board.Invalidate();
    }

    /// <summary>
    /// 画面的"指纹"：分数、等级、消行、状态、当前方块的位置与朝向、预览三格。
    /// 任何一项变了才需要重绘——不把 Frame 算进去，否则每一帧都会变，节流就失效了。
    /// </summary>
    private long StateSignature()
    {
        var state = _engine.State;
        var signature = (long)state.Score;
        signature = (signature * 31) + state.Level;
        signature = (signature * 31) + state.LinesCleared;
        signature = (signature * 31) + (int)state.Status;
        signature = (signature * 31) + (int)state.Active.Kind;
        signature = (signature * 31) + state.Active.X;
        signature = (signature * 31) + state.Active.Y;
        signature = (signature * 31) + state.Active.Rotation;

        foreach (var kind in state.PeekNext(_previews.Length))
        {
            signature = (signature * 31) + (int)kind;
        }

        return signature;
    }

    /// <summary>F4：0.5× / 1× / 2× 循环，只改重力节奏，不改 AI 的观战节拍。</summary>
    private void CycleSpeed()
    {
        _speedIndex = (_speedIndex + 1) % Speeds.Length;
        _lastSignature = -1;   // 强制下一帧刷新 HUD
        _noticeLabel.Text = $"下落速度 {Speeds[_speedIndex]:0.0}×";
        UpdateHud();
        _board.Invalidate();
    }

    /// <summary>
    /// 把这一帧的意图喂给引擎：玩家来自 <see cref="KeyRepeater"/>，AI 来自 <see cref="IPlayerAgent"/>。
    /// 暂停 / 结束 / 失焦时不积累按键，恢复后不会"瞬移一串"。
    /// <para>
    /// AI 在<b>分步档</b>下每 <see cref="AiStepMs"/> 毫秒才发一条指令，硬降落块后再停
    /// <see cref="AiPiecePauseMs"/> 毫秒——这样才能看清"旋转 → 平移 → 落点"。
    /// 极速档（F5）间隔为 0，退回"每帧一条"的原行为。
    /// </para>
    /// </summary>
    private void FeedInput(double deltaMs)
    {
        if (_engine.State.Status != GameStatus.Running)
        {
            _keys.Clear();
            return;
        }

        if (_agent is null)
        {
            foreach (var command in _keys.Collect(NowMs()))
            {
                _engine.Apply(command);
            }

            return;
        }

        // AI 接管期间：玩家的移动/旋转/硬降一律不生效（暂停键已在 ProcessCmdKey 里单独放行）。
        _keys.Clear();

        if (!_aiFast)
        {
            // 分步档没有重力兜底，AI 若一直发不出有效指令就会冻在画面上：超时替它砸下去。
            _aiStallMs += deltaMs;
            if (_aiStallMs >= AiStallLimitMs)
            {
                _engine.Apply(GameCommand.HardDrop);
                _aiStallMs = 0;
                _aiElapsedMs = 0;
                _aiPauseLeftMs = AiPiecePauseMs;
                return;
            }
        }

        if (_aiPauseLeftMs > 0)
        {
            _aiPauseLeftMs -= deltaMs;
            return;
        }

        _aiElapsedMs += deltaMs;
        if (_aiElapsedMs < (_aiFast ? 0 : AiStepMs))
        {
            return;
        }

        _aiElapsedMs = 0;

        try
        {
            var command = _agent.NextCommand(_engine.State);
            if (_engine.Apply(command))
            {
                _aiStallMs = 0;

                if (command == GameCommand.HardDrop)
                {
                    // 落块后停一拍，让玩家看清落点和消行。
                    _aiPauseLeftMs = _aiFast ? 0 : AiPiecePauseMs;
                }
            }
        }
        catch (Exception)
        {
            // AI 契约上不抛异常；真抛了也只能把控制权还给玩家，不能让界面崩掉。
            TurnAgentOff("AI 异常，已切回玩家");
        }
    }

    /// <summary>F5：AI 观战节奏在"分步"和"极速"之间切换。</summary>
    private void ToggleAiPace()
    {
        _aiFast = !_aiFast;
        _aiElapsedMs = 0;
        _aiPauseLeftMs = 0;
        _aiStallMs = 0;

        // 半路换档时丢掉旧计划：分步档下计划是按"重力冻结"算的，沿用会把方块送到错误位置。
        _agent?.Reset();

        _lastSignature = -1;
        _noticeLabel.Text = _aiFast ? "AI 极速（F5 改分步）" : "AI 分步（F5 改极速）";
        UpdateHud();
        _board.Invalidate();
    }

    /// <summary>一次性命令（旋转 / 硬降 / 暂停）与 AI 开关的公共入口。</summary>
    private void ApplyPlayerCommand(GameCommand command)
    {
        if (_agent is not null && command is not (GameCommand.Pause or GameCommand.Resume))
        {
            return;
        }

        // P/Esc 在暂停时应解释为"继续"（引擎只在 Paused 下接受 Resume）。
        if (command == GameCommand.Pause && _engine.State.Status == GameStatus.Paused)
        {
            command = GameCommand.Resume;
        }

        _engine.Apply(command);

        if (_engine.State.Status != GameStatus.Running)
        {
            _keys.Clear();
        }

        _board.State = _engine.State;
        _board.Invalidate();
    }

    /// <summary>F3：在"玩家操作"和"AI 观战"之间切换，棋盘和引擎实例都不换。</summary>
    private void ToggleAgent()
    {
        if (_agent is not null)
        {
            TurnAgentOff("玩家操作（F3 观战）");
            return;
        }

        _agent = new HeuristicAgent(_engine.State.Config, AppBootstrap.CreateRules());
        _agent.Reset();
        _aiElapsedMs = 0;
        _aiPauseLeftMs = 0;
        _aiStallMs = 0;
        _board.ShowAiOverlay = true;
        _board.AiDebug = _agent as IPlayerAgentDebug;
        _noticeLabel.Text = "AI 接管（F3 交回玩家）";
        _board.Invalidate();
        UpdateHud();
    }

    /// <summary>关掉 AI 并把界面恢复成"玩家操作"的样子。</summary>
    private void TurnAgentOff(string? notice)
    {
        _agent = null;
        _board.ShowAiOverlay = false;
        _board.AiDebug = null;
        if (notice is not null)
        {
            _noticeLabel.Text = notice;
        }

        _board.Invalidate();
        UpdateHud();
    }

    /// <summary>暂停 + 清空按键：Alt+Tab、最小化、窗口失焦时调用。</summary>
    private void LeaveGame()
    {
        _keys.Clear();

        if (_engine.State.Status != GameStatus.Running)
        {
            return;
        }

        _engine.Apply(GameCommand.Pause);
        _board.State = _engine.State;
        _board.Invalidate();
    }

    protected override void OnDeactivate(EventArgs e)
    {
        base.OnDeactivate(e);
        LeaveGame();
    }

    protected override void OnResize(EventArgs e)
    {
        base.OnResize(e);

        if (WindowState == FormWindowState.Minimized)
        {
            LeaveGame();
        }
    }

    private void UpdateHud()
    {
        var state = _engine.State;
        _scoreLabel.Text = $"分数  0x{state.Score:X}";
        _highLabel.Text = $"最高  0x{(_highScore?.Score ?? 0):X}";
        _levelLabel.Text = $"等级  {state.Level}";
        _linesLabel.Text = $"消行  {state.LinesCleared}";
        _speedLabel.Text = $"速度  {Speeds[_speedIndex]:0.0}×（F4）";
        _aiPaceLabel.Text = _aiFast ? "AI 节奏  极速（F5）" : "AI 节奏  分步（F5）";

        // 预览用图形控件，不再拼文字；队列不够长时对应那格留空。
        var preview = state.PeekNext(_previews.Length);
        for (var i = 0; i < _previews.Length; i++)
        {
            _previews[i].Kind = i < preview.Count ? preview[i] : null;
        }

        UpdateAiLabel();
    }

    private void UpdateAiLabel()
    {
        if (_agent is null)
        {
            _aiLabel.ForeColor = Palette.Muted;
            _aiLabel.Text = "AI  关闭（F3 观战）";
            return;
        }

        _aiLabel.ForeColor = Palette.Accent;

        var debug = _agent as IPlayerAgentDebug;
        var chosen = debug?.Chosen;
        if (chosen is null)
        {
            _aiLabel.Text = $"AI  {_agent.Name}\n决策中…";
            return;
        }

        // 侧栏的一行：评分 | 消行 | 空洞 | 凹凸（全部取自 AI 选中的那个候选）。
        _aiLabel.Text =
            $"评分 {chosen.Score:F1} | 消行 {chosen.ClearedLines} | 空洞 {chosen.Holes} | 凹凸 {chosen.Bumpiness}";
    }

    private void SaveHighScoreIfNeeded()
    {
        var state = _engine.State;
        if (state.Status != GameStatus.GameOver || _savedThisRound)
        {
            return;
        }

        _savedThisRound = true;

        // 0 分的"新纪录"没有意义（首次游玩一开局就死掉的场合），按"没有更好"处理。
        if (state.Score <= (_highScore?.Score ?? 0))
        {
            return;
        }

        var candidate = new HighScore(state.Score, state.Level, state.LinesCleared, DateTimeOffset.Now);

        // 内存里的"最高分"先更新（本局确实破了纪录，遮罩要显示"新纪录！"），
        // 磁盘写失败时由 _noticeLabel 明确告诉玩家"没保存"，下次启动会回到旧纪录。
        _newRecordThisRound = true;
        _highScore = candidate;

        _noticeLabel.Text = _store.Save(candidate)
            ? "新纪录已保存"
            : "存档写入失败，本局未保存";
    }

    private Control BuildLayout()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Palette.Background,
            Margin = Padding.Empty,
            Padding = Padding.Empty,
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 236f));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

        var boardHost = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Palette.Background,
            Padding = new Padding(12),
        };

        _board.Dock = DockStyle.Fill;
        boardHost.Controls.Add(_board);

        root.Controls.Add(boardHost, 0, 0);
        root.Controls.Add(BuildSidebar(), 1, 0);
        return root;
    }

    private Control BuildSidebar()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 11,
            BackColor = Palette.Background,
            Padding = new Padding(4, 14, 12, 10),
        };
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

        // 行高：四个数字 44/36/30/30，速度 26，"下一个"标题 22，预览区 74，
        // 提示占满剩余，AI 统计 40，AI 节奏 26，通知 34。
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 44f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 36f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 30f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 22f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 74f));
        panel.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 26f));
        panel.RowStyles.Add(new RowStyle(SizeType.Absolute, 34f));

        _scoreLabel = CreateLabel("分数  0x0", 14f, Palette.Accent, FontStyle.Bold);
        _highLabel = CreateLabel("最高  0x0", 11f, Palette.Text, FontStyle.Regular);
        _levelLabel = CreateLabel("等级  1", 11f, Palette.Text, FontStyle.Regular);
        _linesLabel = CreateLabel("消行  0", 11f, Palette.Text, FontStyle.Regular);
        _speedLabel = CreateLabel("速度  1.0×（F4）", 10f, Palette.Muted, FontStyle.Regular);
        _nextLabel = CreateLabel("下一个", 10f, Palette.Muted, FontStyle.Regular);
        _hintLabel = CreateLabel(
            "← →  左右移动\n↑ / X  顺时针\nZ  逆时针\n↓  软降    空格  硬降\nP / Esc  暂停\nF2  重新开始\nF3  AI 观战 / 接管\nF4  下落速度    F5  AI 节奏",
            9.5f,
            Palette.Muted,
            FontStyle.Regular);
        _hintLabel.TextAlign = ContentAlignment.TopLeft;
        _aiLabel = CreateLabel("AI  关闭（F3 观战）", 8.5f, Palette.Muted, FontStyle.Regular);
        _aiLabel.TextAlign = ContentAlignment.TopLeft;
        _aiPaceLabel = CreateLabel("AI 节奏  分步（F5）", 8.5f, Palette.Muted, FontStyle.Regular);
        _aiPaceLabel.TextAlign = ContentAlignment.TopLeft;
        _noticeLabel = CreateLabel(string.Empty, 8.5f, Palette.Muted, FontStyle.Regular);
        _noticeLabel.TextAlign = ContentAlignment.TopLeft;

        panel.Controls.Add(_scoreLabel, 0, 0);
        panel.Controls.Add(_highLabel, 0, 1);
        panel.Controls.Add(_levelLabel, 0, 2);
        panel.Controls.Add(_linesLabel, 0, 3);
        panel.Controls.Add(_speedLabel, 0, 4);
        panel.Controls.Add(_nextLabel, 0, 5);
        panel.Controls.Add(BuildPreviewRow(), 0, 6);
        panel.Controls.Add(_hintLabel, 0, 7);
        panel.Controls.Add(_aiLabel, 0, 8);
        panel.Controls.Add(_aiPaceLabel, 0, 9);
        panel.Controls.Add(_noticeLabel, 0, 10);
        return panel;
    }

    /// <summary>并排放 <see cref="GameConfig.PreviewCount"/> 个图形预览（默认 3 个）。</summary>
    private Control BuildPreviewRow()
    {
        var count = Math.Clamp(_engine.State.Config.PreviewCount, 1, 4);
        var row = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = count,
            RowCount = 1,
            BackColor = Palette.Background,
            Margin = Padding.Empty,
        };

        for (var i = 0; i < count; i++)
        {
            row.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));
        }

        row.RowStyles.Add(new RowStyle(SizeType.Percent, 100f));

        _previews = new NextPieceView[count];
        for (var i = 0; i < count; i++)
        {
            var view = new NextPieceView
            {
                Dock = DockStyle.Fill,
                Margin = new Padding(3, 2, 3, 2),
                Config = _engine.State.Config,
            };

            _previews[i] = view;
            row.Controls.Add(view, i, 0);
        }

        return row;
    }

    private double NowMs() => _clock.Elapsed.TotalMilliseconds;

    private static Label CreateLabel(string text, float size, Color color, FontStyle style) => new()
    {
        Text = text,
        Dock = DockStyle.Fill,
        AutoSize = false,
        BackColor = Color.Transparent,
        ForeColor = color,
        Font = new Font("Microsoft YaHei UI", size, style),
        TextAlign = ContentAlignment.MiddleLeft,
    };
}
